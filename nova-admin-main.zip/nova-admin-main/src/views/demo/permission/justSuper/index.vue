<script setup lang="ts">

</script>

<template>
  <div>
    只有超级管理员可见
  </div>
</template>

<style scoped>

</style>
