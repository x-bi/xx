<script setup lang="ts"></script>

<template>
  <iframe src="https://staging-cn.vuejs.org/" frameborder="0" class="wh-full" />
</template>

<style scoped></style>
