<script setup lang="ts"></script>

<template>
  <iframe src="https://cn.vitejs.dev/guide/" frameborder="0" class="wh-full" />
</template>

<style scoped></style>
