<script setup lang="ts"></script>

<template>
  <ErrorTip type="500" />
</template>

<style lang="scss" scoped></style>
