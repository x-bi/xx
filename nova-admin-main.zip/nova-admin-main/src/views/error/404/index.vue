<script setup lang="ts"></script>

<template>
  <ErrorTip type="404" />
</template>

<style lang="scss" scoped></style>
