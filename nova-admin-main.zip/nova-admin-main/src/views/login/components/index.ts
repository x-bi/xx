import Login from './Login/index.vue'
import Register from './Register/index.vue'
import ResetPwd from './ResetPwd/index.vue'

export { Login, Register, ResetPwd }
