import 'uno.css'
import '@/styles/index.css'

// 全局引入的静态资源
export function install() {
}
